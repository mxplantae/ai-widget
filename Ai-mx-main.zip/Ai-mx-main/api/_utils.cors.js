export const ALLOWED_ORIGINS = new Set([
  "https://mxplantae.com",
  "https://www.mxplantae.com"
]);

export function corsHeaders(origin) {
  return {
    "access-control-allow-origin": origin,
    "access-control-allow-methods": "POST, GET, OPTIONS",
    "access-control-allow-headers": "content-type",
    "access-control-max-age": "86400",
    "vary": "origin"
  };
}

export function preflight(req, origin) {
  if (req.method === "OPTIONS") {
    if (!ALLOWED_ORIGINS.has(origin)) {
      return new Response("Forbidden", { status: 403, headers: { "vary": "origin" } });
    }
    return new Response(null, { status: 204, headers: corsHeaders(origin) });
  }
  return null;
}
