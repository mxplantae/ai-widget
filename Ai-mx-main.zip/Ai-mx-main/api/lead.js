export const config = { runtime: "edge" };
import { ALLOWED_ORIGINS, corsHeaders, preflight } from "./_utils.cors";

// NOTA: Esto es DEMO. La dedupe real debe hacerse en tu DB.
// Aquí usamos una "lista" temporal por IP + correo (no persistente).
const seen = new Map(); // clave: email, valor: timestamp (NO persiste entre despliegues)

export default async function handler(req) {
  const origin = req.headers.get("origin") || "";
  const pf = preflight(req, origin); if (pf) return pf;

  if (!ALLOWED_ORIGINS.has(origin)) {
    return new Response("Forbidden", { status: 403, headers: { "vary": "origin" } });
  }
  if (req.method !== "POST") {
    return new Response("Method not allowed", { status: 405, headers: { "allow": "POST, OPTIONS" } });
  }

  let body = {};
  try { body = await req.json(); } catch {}
  const name = (body.name||"").trim();
  const email = (body.email||"").trim().toLowerCase();
  if (!name || !email) {
    return new Response(JSON.stringify({ success:false, error:"Missing fields" }), {
      status: 400, headers: { "content-type":"application/json", ...corsHeaders(origin) }
    });
  }

  if (seen.has(email)) {
    return new Response(JSON.stringify({ success:false, error:"Already exists" }), {
      status: 409, headers: { "content-type":"application/json", ...corsHeaders(origin) }
    });
  }
  seen.set(email, Date.now());
  console.log("[lead] new:", { name, email, source: body.source || "chatbot-10off" });

  return new Response(JSON.stringify({ success:true }), {
    status: 200, headers: { "content-type":"application/json", ...corsHeaders(origin) }
  });
}
