export const config = { runtime: "edge" };
import { ALLOWED_ORIGINS, corsHeaders, preflight } from "./_utils.cors";

export default async function handler(req) {
  const origin = req.headers.get("origin") || "";
  const pf = preflight(req, origin); if (pf) return pf;

  if (req.method !== "POST") {
    return new Response("Method not allowed", { status: 405, headers: { "allow": "POST, OPTIONS" } });
  }
  if (!ALLOWED_ORIGINS.has(origin)) {
    return new Response("Forbidden", { status: 403, headers: { "vary": "origin" } });
  }

  const apiKey = process.env.OPENAI_API_KEY;
  if (!apiKey) {
    return new Response(JSON.stringify({ error: "Missing OPENAI_API_KEY" }), {
      status: 500, headers: { "content-type": "application/json", ...corsHeaders(origin) }
    });
  }

  let payload;
  try {
    const { messages, model = "gpt-5" } = await req.json();
    if (!Array.isArray(messages)) throw new Error("messages must be an array");
    payload = { model, input: messages.map(m => `${m.role.toUpperCase()}: ${m.content}`).join("\n"), stream: true };
  } catch (e) {
    return new Response(JSON.stringify({ error: e.message || "Bad request" }), {
      status: 400, headers: { "content-type": "application/json", ...corsHeaders(origin) }
    });
  }

  const upstream = await fetch("https://api.openai.com/v1/responses", {
    method: "POST",
    headers: { "content-type": "application/json", "authorization": `Bearer ${apiKey}` },
    body: JSON.stringify(payload)
  });

  if (!upstream.ok || !upstream.body) {
    const errTxt = await upstream.text();
    return new Response(errTxt || "Upstream error", {
      status: 502, headers: { "content-type": "text/plain; charset=utf-8", ...corsHeaders(origin) }
    });
  }

  return new Response(upstream.body, {
    headers: {
      "content-type": "text/event-stream; charset=utf-8",
      "cache-control": "no-cache, no-transform",
      "x-content-type-options": "nosniff",
      ...corsHeaders(origin)
    }
  });
}
